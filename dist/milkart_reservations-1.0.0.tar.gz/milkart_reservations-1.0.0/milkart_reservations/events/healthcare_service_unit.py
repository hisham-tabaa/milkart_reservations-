
import frappe

def on_update(doc, method=None):
    """Handle Healthcare Service Unit updates"""
    # You can add custom logic here when service units are updated
    pass
